using System;
using System.Linq;
class Program {
    static void Main() {
        string l1 = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(l1)) return;
        int n = int.Parse(l1.Trim());
        string l2 = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(l2)) return;
        int[] a = l2.Trim().Split(new char[]{' '}, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
        Array.Sort(a);
        Console.WriteLine(string.Join(" ", a));
    }
}
