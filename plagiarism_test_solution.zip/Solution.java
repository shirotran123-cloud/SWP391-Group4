package com.aita.autograder;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        if (!input.hasNextInt()) {
            input.close();
            return;
        }

        int count = input.nextInt();
        int[] values = new int[count];
        for (int index = 0; index < count; index++) {
            values[index] = input.nextInt();
        }
        input.close();

        mergeSort(values, new int[count], 0, count - 1);

        StringBuilder output = new StringBuilder();
        for (int index = 0; index < count; index++) {
            if (index > 0) output.append(' ');
            output.append(values[index]);
        }
        System.out.println(output);
    }

    private static void mergeSort(int[] data, int[] buffer, int left, int right) {
        if (left >= right) return;

        int middle = left + (right - left) / 2;
        mergeSort(data, buffer, left, middle);
        mergeSort(data, buffer, middle + 1, right);
        merge(data, buffer, left, middle, right);
    }

    private static void merge(int[] data, int[] buffer, int left, int middle, int right) {
        int first = left;
        int second = middle + 1;
        int write = left;

        while (first <= middle && second <= right) {
            if (data[first] <= data[second]) {
                buffer[write++] = data[first++];
            } else {
                buffer[write++] = data[second++];
            }
        }
        while (first <= middle) buffer[write++] = data[first++];
        while (second <= right) buffer[write++] = data[second++];
        for (int position = left; position <= right; position++) {
            data[position] = buffer[position];
        }
    }
}
