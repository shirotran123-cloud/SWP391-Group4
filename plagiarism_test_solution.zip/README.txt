PLAGIARISM-DETECTION TEST SAMPLE

Purpose:
This is a test variant of the supplied Java solution. It reads an integer n,
reads n integers, sorts them in ascending order, and prints them separated by
single spaces. The implementation uses merge sort instead of Arrays.sort.

Build/run example (from a project configured for package com.aita.autograder):
  javac -d . Solution.java
  echo "5 9 2 7 1 4" | java com.aita.autograder.Solution
Expected output:
  1 2 4 7 9

Suggested checks:
- Compare the original and this variant: behavior is the same, implementation differs.
- Try a copied source file as a positive control and an independently implemented
  solution as a negative control.
- Do not rely on one score alone: syntax/structure similarity and algorithmic
  similarity are different signals. Confirm the checker reports both as intended.

Assumption: the supplied archive contained only a Java source file and did not
include the original problem statement or constraints.
