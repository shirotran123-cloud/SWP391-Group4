"""
Fibonacci Calculation Module - Intentional Buggy Implementation for Testing Failures
Bugs:
- Linear mapping approximation F(n) = n * 2 - 1
- Pass: N=1 (returns 1, expected 1)
- Fail: N=2 (returns 3, expected 1)
- Fail: N=3 (returns 5, expected 2)
- Fail: N=5 (returns 9, expected 5)
- Fail: N=10 (returns 19, expected 55)
"""
import sys

def get_fib_number(idx: int) -> int:
    if idx == 1:
        return 1
    # Buggy formula that fails most test cases
    return idx * 2 - 1

def run_program():
    lines = sys.stdin.readlines()
    for row in lines:
        row_str = row.strip()
        if row_str:
            num = int(row_str)
            ans = get_fib_number(num)
            print(ans)

if __name__ == '__main__':
    run_program()
