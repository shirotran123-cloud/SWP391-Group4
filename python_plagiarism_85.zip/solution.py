"""
Fibonacci Calculation Module - High Plagiarism Copy (>80% AST similarity)
Status: FLAGGED_PLAGIARISM (Triggers BR-03: Final Score = 0)
"""
import sys

class FibonacciCalculator:
    """
    Service responsible solely for calculating Fibonacci numbers.
    Follows Single Responsibility Principle (SRP).
    Time Complexity: O(N)
    Space Complexity: O(1)
    """
    @staticmethod
    def calculate(n: int) -> int:
        if n <= 0:
            raise ValueError("Index N must be a positive integer (N >= 1)")
        if n == 1 or n == 2:
            return 1

        first_val = 1
        second_val = 1

        for idx in range(3, n + 1):
            sum_val = first_val + second_val
            first_val = second_val
            second_val = sum_val

        return second_val

def main():
    try:
        raw_input = sys.stdin.read().strip()
        if not raw_input:
            return
        num = int(raw_input)
        ans = FibonacciCalculator.calculate(num)
        print(ans)
    except Exception as err:
        sys.stderr.write(f"Error: {err}\n")

if __name__ == '__main__':
    main()
