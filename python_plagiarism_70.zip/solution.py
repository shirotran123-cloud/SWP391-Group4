"""
Fibonacci Calculation Module - Variant with ~70-76% AST Similarity
Status: FLAGGED_HIGH (Flagged under UC-11 / BR-03 for high similarity >= 70%)
"""
import sys

class FibonacciCalculator:
    @staticmethod
    def calculate(n: int) -> int:
        if n <= 0:
            raise ValueError("Index N must be a positive integer (N >= 1)")
        if n == 1 or n == 2:
            return 1

        prev_val = 1
        curr_val = 1

        step = 3
        while step <= n:
            next_val = prev_val + curr_val
            prev_val = curr_val
            curr_val = next_val
            step += 1

        return curr_val

def main():
    try:
        raw_input = sys.stdin.read().split()
        if not raw_input:
            return
        n = int(raw_input[0])
        result = FibonacciCalculator.calculate(n)
        print(result)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")

if __name__ == '__main__':
    main()
