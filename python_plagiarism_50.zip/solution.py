"""
Fibonacci Calculation Module - Variant with ~50% AST Similarity
Status: SUSPECTED (Warned for plagiarism investigation)
Preserves accurate computation while reorganizing architecture.
"""
import sys

def parse_input_stream():
    buffer = sys.stdin.read().strip()
    if not buffer:
        return None
    return int(buffer)

class CustomProcessor:
    def __init__(self):
        self.audit = []

    def compute(self, n: int) -> int:
        if n < 1:
            return 0
        if n < 3:
            return 1

        first_num = 1
        second_num = 1
        for idx in range(3, n + 1):
            next_val = first_num + second_num
            first_num = second_num
            second_num = next_val
        return second_num

def start():
    val = parse_input_stream()
    if val is not None:
        p = CustomProcessor()
        print(p.compute(val))

if __name__ == '__main__':
    start()
