import sys
def solve():
    d = sys.stdin.read().split()
    if not d: return
    n = int(d[0])
    a = [int(x) for x in d[1:n+1]]
    a.sort()
    print(" ".join(map(str, a)))
if __name__ == '__main__':
    solve()
