"""
Fibonacci Calculation Module - Standard Reference Implementation
Complies with Clean Code & SOLID (Single Responsibility Principle)
Time Complexity: O(N)
Space Complexity: O(1)
"""
import sys

class FibonacciCalculator:
    """
    Service responsible solely for calculating Fibonacci numbers.
    Adheres strictly to the Single Responsibility Principle (SRP).
    """
    @staticmethod
    def calculate(n: int) -> int:
        if n <= 0:
            raise ValueError("Index N must be a positive integer (N >= 1)")
        if n == 1 or n == 2:
            return 1

        prev_val = 1
        curr_val = 1

        for _ in range(3, n + 1):
            next_val = prev_val + curr_val
            prev_val = curr_val
            curr_val = next_val

        return curr_val

def main():
    try:
        raw_input = sys.stdin.read().strip()
        if not raw_input:
            return
        n = int(raw_input)
        result = FibonacciCalculator.calculate(n)
        print(result)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")

if __name__ == '__main__':
    main()
