import java.util.*;
import java.io.*;

public class Solution {
    static int n, m, startNode, endNode;
    static ArrayList<ArrayList<long[]>> graph;
    static long[] d;
    static final long INF = 1000000000000000L;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        if (!scanner.hasNextInt()) return;

        n = scanner.nextInt();
        m = scanner.nextInt();
        startNode = scanner.nextInt();
        endNode = scanner.nextInt();

        graph = new ArrayList<>();
        for (int i = 0; i <= n; i++) {
            graph.add(new ArrayList<>());
        }

        for (int i = 0; i < m; i++) {
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            long w = scanner.nextLong();
            graph.get(u).add(new long[]{v, w});
        }

        d = new long[n + 1];
        Arrays.fill(d, INF);
        d[startNode] = 0;

        PriorityQueue<long[]> pq = new PriorityQueue<>(Comparator.comparingLong(a -> a[1]));
        pq.add(new long[]{startNode, 0});

        while (!pq.isEmpty()) {
            long[] curr = pq.poll();
            int u = (int) curr[0];
            long currentDist = curr[1];

            if (currentDist > d[u]) continue;
            if (u == endNode) break;

            for (long[] edge : graph.get(u)) {
                int nextNode = (int) edge[0];
                long weight = edge[1];
                if (d[u] + weight < d[nextNode]) {
                    d[nextNode] = d[u] + weight;
                    pq.add(new long[]{nextNode, d[nextNode]});
                }
            }
        }

        if (d[endNode] == INF) {
            System.out.println(-1);
        } else {
            System.out.println(d[endNode]);
        }
    }
}
